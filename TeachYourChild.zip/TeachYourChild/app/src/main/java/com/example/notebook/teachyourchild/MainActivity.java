package com.example.notebook.teachyourchild;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }



    public void touch_nose_right(View touch_right)

    {
        ImageView image_touch_nose=(ImageView)findViewById(R.id.image_touch);
        TextView text_touch=(TextView)findViewById(R.id.text_touch);
        image_touch_nose.setImageResource(R.drawable.h1);
            text_touch.setText("Awesome,  It's better not to touch the nose in addition to the need for hand washing after using the tissue paper");}

    public void touch_nose_wrong(View touch_wrong)
    {
        ImageView image_touch_nose=(ImageView)findViewById(R.id.image_touch);
        TextView text_touch=(TextView)findViewById(R.id.text_touch);

        image_touch_nose.setImageResource(R.drawable.s1);
            text_touch.setText("Noooooooooooooo  Unfortunately, you will get infected with the flu ... Avoid touching your nose");
        }

    public void shacking_right(View shaking_right)
    {
        ImageView image_shacking=(ImageView)findViewById(R.id.image_shacking);
        image_shacking.setImageResource(R.drawable.h2);
        TextView text_shaking=(TextView)findViewById(R.id.text_shaking);
        text_shaking.setText(" yesssssssss Avoid shaking hands with people infected with the flu virus .. it protects us from infection");
    }
    public void shacking_wrong(View shacking_wrong)
    {
        ImageView image_shacking=(ImageView)findViewById(R.id.image_shacking);
        image_shacking.setImageResource(R.drawable.s2);
        TextView text_shaking=(TextView)findViewById(R.id.text_shaking);
        text_shaking.setText("Noooooooooooooo  ..,Please do not deal with people infected with the flu ");
    }

    public void immune_system_right(View immune_system_right)
    {
        ImageView image_immune_system=(ImageView)findViewById(R.id.image_immune_system);
        image_immune_system.setImageResource(R.drawable.h3);
        TextView text_immune_system=(TextView)findViewById(R.id.text_immune_system);
        text_immune_system.setText(" sweet!!    You are gorgeous you have to feed on protein-rich fruit in order to strengthen your immune system");
    }
    public void immune_system_wrong(View immune_system_wrong)
    {
        ImageView image_immune_system=(ImageView)findViewById(R.id.image_immune_system);
        image_immune_system.setImageResource(R.drawable.s3);
        TextView text_immune_system=(TextView)findViewById(R.id.text_immune_system);
        text_immune_system.setText("Noooooooooooooo  ...,Taking your medication in order to recover quickly ");
    }
    public void far_enough_right(View far_enough_right)
    {
        ImageView image_far_enough=(ImageView)findViewById(R.id.image_far_enough);
        image_far_enough.setImageResource(R.drawable.h4);
        TextView text_far_enough=(TextView)findViewById(R.id.text_far_enough);
        text_far_enough.setText(" A simple way to avoid colds and flu by maintaining between you and the person with the disease distance.");
    }
    public void far_enough_wrong(View far_enough_wrong)
    {
        ImageView image_far_enough=(ImageView)findViewById(R.id.image_far_enough);
        image_far_enough.setImageResource(R.drawable.s4);
        TextView text_far_enough=(TextView)findViewById(R.id.text_far_enough);
        text_far_enough.setText("Noooooooooooooo  Unfortunately, you will get infected with the flu ... ,");
    }




    public void sterile_material_rigth(View sterile_material_rigth)
    {
        ImageView image_sterile_material=(ImageView)findViewById(R.id.image_sterile_material);
        image_sterile_material.setImageResource(R.drawable.h5);
        TextView text_sterile_material=(TextView)findViewById(R.id.text_sterile_material);
        text_sterile_material.setText(" Excellent !! Because the use of sterile material with you all the time helps to kill bacteria in your hands.");
    }
    public void sterile_material_wrong(View sterile_material_wrong)
    {
        ImageView image_sterile_material=(ImageView)findViewById(R.id.image_sterile_material);
        image_sterile_material.setImageResource(R.drawable.s5);
        TextView text_sterile_material=(TextView)findViewById(R.id.text_sterile_material);
        text_sterile_material.setText("Noooooooooooooo  Unfortunately, you will get infected with the flu ... ");
    }}